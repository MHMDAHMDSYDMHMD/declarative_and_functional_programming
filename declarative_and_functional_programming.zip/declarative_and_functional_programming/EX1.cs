﻿using System;
using System.Linq;
using declarative_and_functional_programming;
using System.Collections.Generic;
namespace declarative_and_functional_programming
{
    public class EX1inFB_ep4
    {
x    }
}
