﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace declarative_and_functional_programming
//{
//    static class businessexample2inFP
//    {
//        public static void execute()
//        {
//            Invoicingpath invoicingpath = new Invoicingpath();
//            Availablitypath availablitypath = new Availablitypath();
//            (order ord, ProcessConfigurations process) = SetConfigurations();
//            Tuple<order, ProcessConfigurations> OrderAndProcess = SetConfigurations();
//            Func<order, Double> CostOfOrder = CalcAdjustedCostOfOrder(process, invoicingpath, availablitypath);
//            Console.WriteLine(CostOfOrder(ord);
//            Console.WriteLine(CostOfOrder(OrderAndProcess.Item1);
//        }
//        public static Func<order, double> CalcAdjustedCostOfOrder(ProcessConfigurations p, Availablitypath a, Invoicingpath i)
//        {
//            return (x) => AdjustedCost(x, InvoicingpathFunc(p, i,), availablitypathFunc(p, a));
//        }
//        public static double AdjustedCost(order o, Func<order, Freight> calcfreight, Func<order, ShippingDate> calcshippingdaTe)
//        {
//            Freight f = calcfreight(o);
//            ShippingDate s = calcshippingdaTe(o);

//        }
//    }
//    class Availablitypath { }
//    class Invoicingpath { }
//    class Freight { }
//    class ShippingDate { }


//}
