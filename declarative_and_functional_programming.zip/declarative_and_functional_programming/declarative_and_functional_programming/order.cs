﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace declarative_and_functional_programming
{
    class order
    {
        
        private int orderid;
        public int OrderID
        {
            get { return orderid; }
            set { orderid = value; }
        }

        private  int productindex;
        public  int ProductIndex
        {
            get { return productindex; }
            set { productindex = value; }
        }

        private int quantity;
        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        private  int uniprice;
        public  int UniPrice
        {
            get { return uniprice; }
            set { uniprice = value; }
        }

        private  decimal discount;
        public  decimal Discount
        {
            get { return discount; }
            set { discount = value; }
        }
    }
}
