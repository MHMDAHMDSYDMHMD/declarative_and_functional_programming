﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using declarative_and_functional_programming;
namespace declarative_and_functional_programming
{
    class hello
    {
        private double x;
        private double y;
        public hello(double x1, double y1)
        {
            x = x1; y = y1;
        }
        public double getz(double v)
        {
            double z;
            if (x > 10)
                z = (x + y) / 2 + v;
            else
                z = (x - y) / 2 - v;
            return z;
        }
        public void updatex(double v)
        {
            x = y + 2 * v;
        }
        public void updatey(double v)
        {
            y = x + 2 * v;
        }

    }
}
