﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace declarative_and_functional_programming
{
    class exaple1inFB
    {

        public static  List<order> OrdersForProccessing = new List<order>();
        public static order getorderwithdiscount(order r , List<Tuple<Func<order, bool>, Func<order, decimal>>> rules)
        {
            var discount = rules.Where((a) => a.Item1(r)).Select((b) => b.Item2(r)).OrderBy((x) => x).Take(3).Average();
            var neworder = new order();
            neworder.Discount = discount;
            return neworder;
        }
        public static List<Tuple<Func<order, bool> , Func<order, decimal>>> getdiscountrules()
        {
            List<Tuple<Func<order, bool>, Func<order, decimal>>> discountrules = new List<Tuple<Func<order, bool>, Func<order, decimal>>>();
            //{ (isaqualified,a),(isbqualified,b),(iscqualified,c) };
            //discountrules.Add((isaqualified, a));
                return discountrules;
        }
        public bool isaqualified(order r) { return true; }
        public decimal a(order r) { return 1m; }
        public bool isbqualified(order r) { return true; }
        public decimal b(order r) { return 1m; }
        public bool iscqualified(order r) { return true; }
        public decimal c(order r) { return 1m; }

    }
}
