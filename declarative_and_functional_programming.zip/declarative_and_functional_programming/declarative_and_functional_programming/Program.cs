﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace declarative_and_functional_programming
{
   internal static class Program
    {
        #region Initialize
        private static List<double> My_Data = new List<double>() { 7, 4, 5, 6, 3, 8, 10, 11 };
        public static Func<Double, Double> mycomposedfunction = composedfunction(addone, square, subratten);
        // public static Func<double,Double> mycomposedfunctionGeneric = composedfunctionGeneric<double,double,double>(addone, square, subratten);
        private static List<int> NUMsOfIEnumerable = new List<int>() { 0,1,2,3, 4, 5, 6, 3, 8, 10 };
        #endregion Initialize
        public static void Main(string[] args)
        {
            #region ex1
            //var orderswithdiscount = exaple1inFB.OrdersForProccessing.Select((x) => exaple1inFB.getorderwithdiscount(x, exaple1inFB.getdiscountrules()));
            #endregion
            #region example of business 2 in FP
            // businessexample2inFP.execute();
            #endregion
            #region imparative
            //Console.WriteLine("imparative way of doing things");
            //foreach (double x in My_Data)
            //{
            //    Console.WriteLine(subratten(square(addone(x))).ToString());
            //}
            //Console.WriteLine();
            #endregion
            #region declarative
            //Console.WriteLine();
            //Console.WriteLine("declarative way of doing things");
            //My_Data.Select(addone).Select(square).Where(x => x < 70).OrderBy(x => x).Take(7).
            //    Select(subratten).ToList().ForEach((x) => Console.WriteLine(x.ToString()));
            //Console.WriteLine();
            #endregion
            #region higher order function
            //Console.WriteLine();
            //Console.WriteLine("higher order function");
            //Func<double, double> dlgtTest1 = test1;
            //Func<double, double> dlgtTest2 = test2;
            //List<Func<Double, Double>> funcs = new List<Func<Double, Double>>
            //{ dlgtTest1,dlgtTest2 };

            //Console.WriteLine("test2(test1(5)).ToString() : " + test2(test1(5)).ToString());
            //Console.WriteLine("test1(test2(5)).ToString() : " + test1(test2(5)).ToString());

            //Console.WriteLine("funcs[0](5).ToString() : " + funcs[0](5).ToString());
            //Console.WriteLine("funcs[1](5).ToString() : " + funcs[1](5).ToString());

            //Console.WriteLine("funcs[1](funcs[0](5)).ToString() : " + funcs[1](funcs[0](5)).ToString());
            //Console.WriteLine("funcs[0](funcs[1](5)).ToString() : " + funcs[0](funcs[1](5)).ToString());


            //Console.WriteLine("test3(test1(5)) : " + test3(test1,5));
            //Console.WriteLine("test3(test1(5)) : " + test3(test1,5));
            //Console.WriteLine();
            #endregion
            #region function return function
            //Func<Double, Double> myfunction = test();
            //Console.WriteLine(myfunction(4).ToString());
            //My_Data.Select(mycomposedfunction).ToList().ForEach((x) => Console.WriteLine(x.ToString()));
            //Console.WriteLine();
            #endregion FRF
            #region function return function Generic
            //Func<Double, Double> myfunctionGeneric = test();
            //Console.WriteLine(myfunction(4).ToString());
            //My_Data.Select(mycomposedfunctionGeneric).ToList().ForEach((x) => Console.WriteLine(x.ToString()));
            //My_Data.Select(addonesquaresubtracten()).ToList().ForEach((x) => Console.WriteLine(x.ToString()));
            //Console.WriteLine();
            #endregion FRFGeneric
            #region Closures main
            //var q1 = testClosures(10);
            //Console.WriteLine(q1(4));
            //var q2 = testClosures(20);
            //Console.WriteLine(q2(4));// access to function a
            //                         //grossSalary
            //List<Tuple<string, double>> zfuncs = new List<Tuple<string, double>>();
            //List < (string,double basicsal)> zfuncs = new List<(string seg, double basicsal)>  {("a",1000),("c",2000),("d",3000) };
            //var grosssalarycalaulators = zfuncs.Select((a) =>
            //(
            //return (id:a.seg, mygrosssalarycalaulators: grosssalarycalaulator(a.basicsal));
            //)).ToList();
            //Console.WriteLine(grosssalarycalaulators[0].mygrosssalarycalaulators(80));
            //Console.WriteLine(grosssalarycalaulators[1].mygrosssalarycalaulators(90));
            //Console.WriteLine(grosssalarycalaulators.FirstOrDeflaut((m)=>m.id=="c").mygrosssalarycalaulators(100));
            #endregion
            #region IEnumerableMAINs
            //var datafetch = onebyone();
            //foreach (var item in datafetch)
            //{
            //    Console.WriteLine(item);
            //}
            #endregion IEnumerableMAINs
            #region MAINsOfItrator or declarative TO imperative
            //EXECUTEimperative();
            #endregion MAINsOfItrator or declarative TO imperative
            #region training 
            #endregion training
            Console.ReadKey();
        }
        #region Functions OF Training 
        static Func<T1,T2> retur
        #endregion 
        #region FUNCsOfItrator or declarative TO imperative
        public static IEnumerable<double> Doaddone()
        {
            foreach (var item in My_Data)
            {
                yield return addone(item);
            }
        }
        public static IEnumerable<double> Dosquare()
        {
            foreach (var item in Doaddone())
            {
                yield return square(item);
            }
        }
        public static IEnumerable<double> Dosubtractten()
        {
            foreach (var item in Dosquare())
            {
                yield return subratten(item);
            }
        }
        public static IEnumerable<double> DoWhere()
        {
            Func<double, bool> w = (x) => x > 5;
            foreach (var item in Dosubtractten())
            {
                if (w(item))
                {
                    yield return item;
                }
            }
        }
        public static IEnumerable<double> DoTakeTwo()
        {
            var n = 2;int i = 0;
            IEnumerable<double> cursor = (IEnumerable<double>)(DoWhere().GetEnumerator());
            do
            {
                if (i != n) { cursor.MoveNext(); }
                var v = cursor.Current;
                if (i < n)
                {
                    yield return v;
                    i++;
                }
                else yield break;
            } while (true);
        }
        public static void EXECUTEimperative()
        {
            var result = DoTakeTwo().ToList();
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
        }
        #endregion FUNCsOfItrator or declarativeTOimparative
        #region IEnumerable FUNCs
        public static IEnumerable<int> onebyone()
        {
            Console.WriteLine("i here onebyone");
            foreach (var item in NUMsOfIEnumerable)
            {
                yield return (item);
            }
        }
        #endregion IEnumerableFUNCs
        #region Closures     
        public static Func<Double, Double> testClosures(double x)
        {
            Console.WriteLine("i'm" + x.ToString());
            var x1 = x + 10;
            return (double a) => { return a + x1; }; // not pure function
        }
        public static Func<double,double> grosssalarycalaulator(double basicsalary)
        {
            var tax = 0.2 * basicsalary;
            return (double bonus) =>
             {
                 return bonus + tax + basicsalary;
             };
        }
        #endregion
        #region function return function
        public static Func<Double,Double> composedfunction(Func<Double, Double> f1, Func<Double, Double> f2, Func<Double, Double> f3)
        {
            return (x) => { return f1(f2(f3(x))); };
        }
        #endregion FRFfunctions
        #region  function return function functionsGeneric
        public static Func<t1, t3> composedfunctionGeneric<t1,t2,t3>(this Func<t1, t2> f, Func<t2, t3> g)
        {
            return (x) => { return g(f(x)); };
        }
        public static Func<double , double> addonesquaresubtracten()
        {
            Func<double, double> q1 = addone;
            Func<double, double> q2 = square;
            Func<double, double> q3 = subratten;
            return q1.composedfunctionGeneric(q2).composedfunctionGeneric(q3);
        }
        #endregion FRFfunctionsGeneric
        #region declarative functions
        static double subratten(double i)
        {
            i -= 10;
            return i;
        }
        static double square(double i)
        {
            i *= i;
            return i;
        }
        static double addone(double i)
        {
            i += 1;
            return i;
        }
        #endregion
        #region FUNCTIONS OF (higher order function)
        public static Func<Double, Double> test()
        {
            return v => v + 2;
        }
        public static double test1(double x)
        {
            return x / 2;
        }
        public static double test2(double x)
        {
            return x / 4 + 1;
        }
        public static double test3(Func<double , double> f,  double x)
        {
            return f(x) + x;
        }
        #endregion FUNCTIONS OF (higher order function)

    }
    }
